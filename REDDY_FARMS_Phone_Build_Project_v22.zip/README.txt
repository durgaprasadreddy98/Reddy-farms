REDDY FARMS V9 — Android project source

V9 change:
- Bottle charge fixed rates: 1L bottle = ₹50; 500ml bottle = ₹25.
- Bottle charges are added to the customer bill for bottles currently not returned.
- Every returned bottle reduces the outstanding bottle count and therefore subtracts
  ₹50 (1L) or ₹25 (500ml) from the bottle charge in the bill.
- The bill calculates net unreturned bottles across recorded delivery history:
  given count minus returned count, never below zero.

V8 features retained:
- Short WhatsApp delivery message without customer name
- Customer cow/buffalo pack size, quantity and rate
- Flat number and building name
- Daily, alternate, weekday and custom schedules
- Customer edit
- Past delivery edit and duplicate prevention per customer/date
- Farmer milk collection name, phone, fat, SNF, type, litres, price and date
- Existing storage keys and offline data model

INSTALLATION:
Open in Android Studio and build APK. Install as an update over the previous app.
Do not uninstall the old app or clear app data; applicationId remains unchanged.
This ZIP is source code, not a prebuilt APK.

LIMITATIONS:
Offline single-device app; no cloud sync, live GPS or silent WhatsApp send.
WhatsApp message is prepared and requires the user to tap Send.


V19 update: Added backdated/previous-days delivery entry helper. Select a customer and date range, preview missing scheduled days, uncheck any day when milk was not delivered (saved as No Milk), then save. Existing customer/date records are skipped. Review the generated quantities before saving and verify the monthly bill. Backup/restore storage keys are unchanged.


V20 update: Delivery screen now clearly shows the customer's scheduled litres for the selected date and explains that the actual delivered pack size/quantity can be changed. Billing continues to use the actual saved cow/buffalo litres, not the planned schedule. For example, change 1L to 500ml and set 1 pack to record 0.5L.
