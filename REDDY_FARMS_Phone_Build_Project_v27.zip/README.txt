REDDY FARMS V26 — Simple Delivery & Billing App

V26 changes:
- Replaced the old short WhatsApp delivery text with one consistent customer message template.
- Message uses "Dear Customer" (no customer name).
- Shows the actual delivery date, cow/buffalo milk quantities, returned bottle counts,
  this-month milk bill, old bill due, bottle charges, amount paid, advance adjustment,
  and total outstanding.
- Uses the approved closing line: "Thank you for being a part of REDDY FARMS family! ❤️"
- Uses real line breaks in the WhatsApp message (not visible \\n text).
- Same template is used from the delivery confirmation and delivery-boy WhatsApp action.

V25 functionality and local storage keys are retained. Existing customer and delivery
records remain on the device when installing as an update. Do not uninstall the old app
or clear app data before exporting a backup.

Build:
Open this project in Android Studio and build the APK, or push to GitHub and use the
included Actions workflow. This ZIP is Android source code, not a prebuilt APK.

Important:
- Offline single-device app; no cloud sync or live GPS.
- WhatsApp opens a prepared message; the user must tap Send.
- Verify bill calculations with real customer records before sending bills. Old bill due
  uses the customer's saved oldDue field; month bill uses completed deliveries in that month.


V27 UPDATE - FREE WHATSAPP DELIVERY MESSAGE
- After a new delivery is saved as Delivered, the app opens WhatsApp with the finalized REDDY FARMS bill message pre-filled. The delivery boy must tap Send.
- No WhatsApp API, subscription, or message automation provider is used. WhatsApp's normal message/data charges, if any, are subject to the user's mobile plan.
- Phone numbers with 10 digits are automatically prefixed with India's +91 country code.
- Android opens WhatsApp/browser links outside the app.
- Existing localStorage data keys and applicationId are unchanged. Do not uninstall the previous app or clear app data when updating.
