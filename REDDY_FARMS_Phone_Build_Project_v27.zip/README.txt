REDDY FARMS V27
Simple Delivery & Billing App

Base: V26 source project.
Application ID retained: com.reddyfarms.app
Version: 27.0 (versionCode 23)

V27 additions:
- Save current customer GPS location from Customer list (Save GPS / Update GPS).
- Google Maps navigation uses saved GPS coordinates when available; falls back to address text.
- V27 Operations panel: tomorrow milk demand, bottle balances, daily cash/UPI totals,
  manual cash/UPI closing record, delivery boy performance, customer delivery history,
  and WhatsApp pending-bill reminders.
- Delivery result includes additional failure reasons.
- Delivery record stores payment mode and optional photo filename metadata.
- Existing storage keys for customers, deliveries, payments, expenses, milkStocks,
  and cashHandovers are retained.

IMPORTANT:
- Export a JSON backup from V26 before installing/updating.
- GPS requires Android location permission and device Location to be enabled.
- Photo proof input is optional; this offline build records the selected filename only.
  Persistent image upload/storage is not implemented.
- Data remains local to this phone. Multi-device live sync requires a cloud backend.
- PDF ledger generation is not implemented in this source build; existing bill screen
  and print/share workflows remain unchanged.
- Test on a backup copy first. Do not clear app data or uninstall the old app.
