REDDY FARMS V26 — Simple Delivery & Billing App

V26 changes:
- Replaced the old short WhatsApp delivery text with one consistent customer message template.
- Message uses "Dear Customer" (no customer name).
- Shows the actual delivery date, cow/buffalo milk quantities, returned bottle counts,
  this-month milk bill, old bill due, bottle charges, amount paid, advance adjustment,
  and total outstanding.
- Uses the approved closing line: "Thank you for being a part of REDDY FARMS family! ❤️"
- Uses real line breaks in the WhatsApp message (not visible \\n text).
- Same template is used from the delivery confirmation and delivery-boy WhatsApp action.

V25 functionality and local storage keys are retained. Existing customer and delivery
records remain on the device when installing as an update. Do not uninstall the old app
or clear app data before exporting a backup.

Build:
Open this project in Android Studio and build the APK, or push to GitHub and use the
included Actions workflow. This ZIP is Android source code, not a prebuilt APK.

Important:
- Offline single-device app; no cloud sync or live GPS.
- WhatsApp opens a prepared message; the user must tap Send.
- Verify bill calculations with real customer records before sending bills. Old bill due
  uses the customer's saved oldDue field; month bill uses completed deliveries in that month.
