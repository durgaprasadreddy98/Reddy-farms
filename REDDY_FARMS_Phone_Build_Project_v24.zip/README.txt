REDDY FARMS V9 — Android project source

V9 change:
- Bottle charge fixed rates: 1L bottle = ₹50; 500ml bottle = ₹25.
- Bottle charges are added to the customer bill for bottles currently not returned.
- Every returned bottle reduces the outstanding bottle count and therefore subtracts
  ₹50 (1L) or ₹25 (500ml) from the bottle charge in the bill.
- The bill calculates net unreturned bottles across recorded delivery history:
  given count minus returned count, never below zero.

V8 features retained:
- Short WhatsApp delivery message without customer name
- Customer cow/buffalo pack size, quantity and rate
- Flat number and building name
- Daily, alternate, weekday and custom schedules
- Customer edit
- Past delivery edit and duplicate prevention per customer/date
- Farmer milk collection name, phone, fat, SNF, type, litres, price and date
- Existing storage keys and offline data model

INSTALLATION:
Open in Android Studio and build APK. Install as an update over the previous app.
Do not uninstall the old app or clear app data; applicationId remains unchanged.
This ZIP is source code, not a prebuilt APK.

LIMITATIONS:
Offline single-device app; no cloud sync, live GPS or silent WhatsApp send.
WhatsApp message is prepared and requires the user to tap Send.


V19 update: Added backdated/previous-days delivery entry helper. Select a customer and date range, preview missing scheduled days, uncheck any day when milk was not delivered (saved as No Milk), then save. Existing customer/date records are skipped. Review the generated quantities before saving and verify the monthly bill. Backup/restore storage keys are unchanged.


V20 update: Delivery screen now clearly shows the customer's scheduled litres for the selected date and explains that the actual delivered pack size/quantity can be changed. Billing continues to use the actual saved cow/buffalo litres, not the planned schedule. For example, change 1L to 500ml and set 1 pack to record 0.5L.


V23 update:
- Preserves existing 500ml/1L cow and buffalo quantity selection and saved actual quantities.
- After a completed delivery is saved or edited, prepares a WhatsApp delivery confirmation with today's milk quantities, rates, amount, bottle given/returned counts, tomorrow requirement and current monthly due summary.
- Adds a "Send monthly bill on WhatsApp" action to Customer Billing.
- WhatsApp phone numbers are normalized: a 10-digit Indian mobile number is prefixed with 91.
- Android app opens WhatsApp / WhatsApp Business externally for wa.me links.
- Existing offline storage keys and customer/delivery records are retained. Install as an update; do not uninstall or clear app data.
- WhatsApp messages are prepared for review; the delivery partner/customer still needs to tap Send.

V24 delivery partner page update:
- Reworks the Delivery Boy home page into a mobile-first route dashboard with today's date, total scheduled litres, total stops, delivered/remaining counts and progress.
- Adds customer search by name, phone, area and address; area filter; All/Pending/Delivered/Other filters.
- Adds customer stop cards with planned milk quantity, cow/buffalo type, address, phone and 1L/500ml bottle balance.
- Adds quick actions to open/change actual delivery quantity, mark Delivered, No Milk or Customer Not Available.
- Adds per-customer Google Maps navigation and WhatsApp contact shortcuts; route map opens a Google Maps directions link using saved customer addresses.
- Uses the existing delivery form and save logic, preserving actual 500ml/1L pack selection, bottle returns, cash collection, tomorrow YES/NO/PAUSE and WhatsApp delivery confirmation.
- Existing localStorage keys, customer data, delivery history, billing and backup/restore format are retained.
- UI JavaScript syntax checked with Node. Android APK build/device installation has not been run in this environment.
