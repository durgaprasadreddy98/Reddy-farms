from pathlib import Path
p=Path('/mnt/data/v20work/app/src/main/assets/index.html')
s=p.read_text()
s=s.replace('<div class="two"><div class="field"><label>Cash collected now (₹)</label><input id="cashCollected" type="number" min="0" value="0"></div><div class="field"><label>Tomorrow requirement</label><select id="tomorrow"><option value="YES">YES – Send milk</option><option value="NO">NO – No milk</option><option value="PAUSE">PAUSE</option></select></div></div>', '''<div class="two"><div class="field"><label>Cash collected now (₹)</label><input id="cashCollected" type="number" min="0" value="0"></div><div class="field"><label>Tomorrow requirement</label><select id="tomorrow" onchange="prefillTomorrowQty()"><option value="YES">YES – Send milk</option><option value="NO">NO – No milk</option><option value="PAUSE">PAUSE</option></select></div></div>
<div class="card" style="background:#f7faf8;box-shadow:none"><h3>Tomorrow quantity (editable)</h3><p class="muted">Set tomorrow's cow and buffalo milk separately. This updates tomorrow's delivery and filling requirement.</p><div class="two"><div class="field"><label>Cow milk (litres)</label><input id="tomorrowCowQty" type="number" min="0" step="0.5" value="0"></div><div class="field"><label>Buffalo milk (litres)</label><input id="tomorrowBuffQty" type="number" min="0" step="0.5" value="0"></div></div></div>''')
# Insert helper before prefillCustomer
needle='function prefillCustomer(){'
helper='''function prefillTomorrowQty(){let c=customers.find(x=>String(x.id)===String($('dcustomer').value));if(!c)return;let date=nextDay($('deliveryEntryDate').value||today()),o=(c.tomorrowQtyOverrides||{})[date];if(o){$('tomorrowCowQty').value=Number(o.cow)||0;$('tomorrowBuffQty').value=Number(o.buffalo)||0;return}let total=scheduleQty(c,date),baseCow=c.milk==='Buffalo'?0:Number(c.cowQty??c.defaultQty??1)*Number(c.cowSize??1),baseBuff=c.milk==='Cow'?0:Number(c.buffaloQty??0)*Number(c.buffaloSize??1),base=baseCow+baseBuff,cow=c.milk==='Buffalo'?0:c.milk==='Cow'?total:(base?total*baseCow/base:total);$('tomorrowCowQty').value=c.milk==='Buffalo'?0:Number(cow.toFixed(2));$('tomorrowBuffQty').value=c.milk==='Cow'?0:Number((total-cow).toFixed(2));}
'''
s=s.replace(needle,helper+needle)
# after deliveryResultChanged call at end of prefillCustomer
s=s.replace("$('cashCollected').value=0;deliveryResultChanged()}","$('cashCollected').value=0;deliveryResultChanged();prefillTomorrowQty()}")
# editing saved delivery should refresh tomorrow qty after setting select
s=s.replace("$('tomorrow').value=d.tomorrow||'YES';$('cancelDeliveryEdit')", "$('tomorrow').value=d.tomorrow||'YES';prefillTomorrowQty();$('cancelDeliveryEdit')")
# save overrides when save delivery
s=s.replace("deliveries=old?deliveries.map(x=>String(x.id)===String(old.id)?d:x):[d,...deliveries];c.tomorrow=d.tomorrow;c.tomorrowDate=nextDay(date);persist();", "deliveries=old?deliveries.map(x=>String(x.id)===String(old.id)?d:x):[d,...deliveries];c.tomorrow=d.tomorrow;c.tomorrowDate=nextDay(date);c.tomorrowQtyOverrides=c.tomorrowQtyOverrides||{};if(d.tomorrow==='YES'){c.tomorrowQtyOverrides[c.tomorrowDate]={cow:Math.max(0,Number($('tomorrowCowQty').value)||0),buffalo:Math.max(0,Number($('tomorrowBuffQty').value)||0)};}else{delete c.tomorrowQtyOverrides[c.tomorrowDate];}persist();")
# scheduleQty override at start
s=s.replace("function scheduleQty(c,date){let day=new Date(date+'T12:00:00');", "function scheduleQty(c,date){let override=(c.tomorrowQtyOverrides||{})[date];if(override)return Math.max(0,Number(override.cow)||0)+Math.max(0,Number(override.buffalo)||0);let day=new Date(date+'T12:00:00');")
# update hint wording
s=s.replace('Customer schedule for \'+date+\': \'+planned.toFixed(2)+\' L. Actual delivered quantity can be different—change pack size and pack count below; billing uses the actual saved litres.', 'Customer requirement for \'+date+\': \'+planned.toFixed(2)+\' L. Change today\'s actual pack size and count below; billing uses actual saved litres.')
p.write_text(s)
