REDDY FARMS Android starter project

This is an Android Studio project source, not a compiled APK.
To build:
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Let Gradle sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

The app stores records locally on the device using WebView localStorage.
WhatsApp messages are prepared and opened for the user to send; this is not
background auto-send. Export JSON backups regularly. Uninstalling or clearing
app data can erase local records.

For production use, test backup/restore and bottle accounting thoroughly.
