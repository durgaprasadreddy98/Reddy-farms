package com.reddyfarms.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new BackupBridge(), "AndroidBackup");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    private class BackupBridge {
        @JavascriptInterface
        public String saveBackup(String filename, String content) {
            try {
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
                values.put(MediaStore.MediaColumns.MIME_TYPE, "application/json");
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    values.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download");
                }
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("Could not create backup file");
                OutputStream out = getContentResolver().openOutputStream(uri);
                if (out == null) throw new Exception("Could not write backup file");
                out.write(content.getBytes("UTF-8"));
                out.close();
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Backup saved in Downloads", Toast.LENGTH_LONG).show());
                return "Backup saved in Downloads: " + filename;
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Backup failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
                return "Backup failed: " + e.getMessage();
            }
        }
    }
    @Override public void onBackPressed() { super.onBackPressed(); }
}
